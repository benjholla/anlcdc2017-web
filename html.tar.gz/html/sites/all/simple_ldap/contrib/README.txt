This folder consists of small helper modules that cover some one-off
situations. These modules are not officially supported, and mostly serve as
examples of how to bridge the gaps between the base functionality of the
simple_ldap family of modules, and any special requirements a site might have.

Feel free to use these modules as appropriate. Bug fixes, revies, and other
helper module contributions are welcome!
